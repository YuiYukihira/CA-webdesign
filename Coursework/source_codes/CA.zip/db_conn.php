<?php
// Database cannections should be moved into a file outside of the publicly accessable directory.
$dbservername = "emps-sql.ek.ac.uk";
$dbusername = "as1200";
$dbpassword = "as1200";
$dbdatabase = "as1200";
?>
